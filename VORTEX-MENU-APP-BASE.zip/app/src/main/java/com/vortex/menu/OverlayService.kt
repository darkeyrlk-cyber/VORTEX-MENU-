package com.vortex.menu

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val channelId = "vortex_overlay"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        startForeground(7, notification())
        showBubble()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "VORTEX MENU", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        return builder.setContentTitle("VORTEX MENU ativo")
            .setContentText("A bolha flutuante está disponível.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 220 }
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "♛\nV"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(105, 35, 150))
            setPadding(16, 12, 16, 12)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        val p = params(WRAP_CONTENT, WRAP_CONTENT)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) { if (panel == null) showPanel() else hidePanel() }
                        return true
                    }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(Color.rgb(20, 15, 28))
        }
        val heading = TextView(this).apply {
            text = "♛ VORTEX MENU"
            textSize = 21f
            setTextColor(Color.rgb(205, 120, 255))
        }
        box.addView(heading)
        box.addView(toggle("Animações de interface"))
        box.addView(toggle("Vibração de demonstração"))
        box.addView(toggle("Modo compacto"))
        val close = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener { hidePanel() }
        }
        box.addView(close)
        panel = box
        val p = params(300, WRAP_CONTENT).apply { x = 110; y = 260 }
        wm.addView(box, p)
    }

    private fun toggle(label: String): Switch {
        return Switch(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = false
        }
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
