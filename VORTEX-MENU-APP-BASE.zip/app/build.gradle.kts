plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vortex.menu"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vortex.menu"
        minSdk = 29
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
